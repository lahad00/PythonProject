import mysql.connector
from subprocess import call
from tkinter import CENTER, ttk, Tk, messagebox, Label, Entry, Button

# Fonction Connexion
def Connecter():
    user = txtnomUtilisateur.get()
    password = txtmdp.get()
    statut = combostatut.get()

    if user == "" or password == "":
        messagebox.showerror("Erreur", "Veuillez renseigner tous les champs")
        return

    try:
        # Connexion à la base de données
        maBase = mysql.connector.connect(host="localhost", user="root", password="", database="test")
        meConnect = maBase.cursor()

        # Vérification des identifiants
        query = "SELECT * FROM inscription WHERE user = %s AND password = %s AND statut = %s"
        val = (user, password, statut)
        meConnect.execute(query, val)
        result = meConnect.fetchone()

        if result:
            messagebox.showinfo("Information", "Bienvenue, connexion réussie !")
            root.destroy()
            # Redirection vers un script en fonction du statut
            if statut == "Etudiant":
                call(["python", "C:/Users/Lahad/OneDrive/Documents/KONAMI/pythonProject/gestEleves/etudiants.py"])
            elif statut == "Professeur":
                call(["python", "C:/Users/Lahad/OneDrive/Documents/KONAMI/pythonProject/gestEleves/Menu_principal.py"])
        else:
            messagebox.showwarning("Erreur", "Identifiants incorrects")
    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur de connexion à la base de données : {e}")
    finally:
        maBase.close()

# Fonction Inscrire
def Inscrire():
    try:
        root.destroy()
        call(["python", "C:/Users/Lahad/OneDrive/Documents/KONAMI/pythonProject/gestEleves/inscription.py"])
    except Exception as e:
        messagebox.showerror("Erreur", f"Impossible d'ouvrir le fichier d'inscription : {e}")

# Création de la fenêtre principale
root = Tk()
root.title("FENETRE DE CONNEXION")
root.configure(background="#091821")

# Mode plein écran
root.state('zoomed')

# Dimensions de la fenêtre
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Fonction utilitaire pour centrer les widgets
def center_widget(widget, relx, rely, width=400, height=40):
    widget.place(relx=relx, rely=rely, anchor=CENTER, width=width, height=height)

# Ajout du Titre
lbltitre = Label(root, text="Connexion", font=("Sans Serif", 30), bg="#091821", fg="white")
center_widget(lbltitre, relx=0.5, rely=0.1, width=600)

# Champ Nom utilisateur
lblutilisateur = Label(root, text="Nom utilisateur:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblutilisateur, relx=0.4, rely=0.25)
txtnomUtilisateur = Entry(root, bd=4, font=("Arial", 16))
center_widget(txtnomUtilisateur, relx=0.6, rely=0.25)

# Champ Mot de passe
lblmdp = Label(root, text="Mot de passe:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblmdp, relx=0.4, rely=0.35)
txtmdp = Entry(root, show="*", bd=4, font=("Arial", 16))
center_widget(txtmdp, relx=0.6, rely=0.35)

# Liste déroulante Statut
lblstatut = Label(root, text="Statut:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblstatut, relx=0.4, rely=0.45)
combostatut = ttk.Combobox(root, font=("Arial", 16))
combostatut['values'] = ['Etudiant', 'Professeur']
center_widget(combostatut, relx=0.6, rely=0.45)

# Bouton Connexion
btnconnexion = Button(root, text="Connexion", font=("Arial", 16), bg="#FF4500", fg="white", command=Connecter)
center_widget(btnconnexion, relx=0.5, rely=0.6)

# Bouton Inscription
btninscrire = Button(root, text="Inscris toi!", cursor="hand2", font=("Arial", 16), bd=0, bg="#091821", fg="#FF4500", command=Inscrire)
center_widget(btninscrire, relx=0.5, rely=0.7, width=200)

# Bouton Quitter
btnquitter = Button(root, text="Quitter", font=("Arial", 16), bg="#FF4500", fg="white", command=root.quit)
center_widget(btnquitter, relx=0.5, rely=0.8, width=200)

# Lancement de la fenêtre principale
root.mainloop()
