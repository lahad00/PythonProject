# Bibliothèques

import mysql.connector
import tkinter
from subprocess import call
from tkinter import ttk, Tk
from tkinter import *
from tkinter import messagebox
from cProfile import label
import csv

# Fonction pour revenir à l'écran de connexion
def Retour():
    root.destroy()
    call(["python", "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\connexion.py"])


# Fonction pour obtenir une connexion à la base de données
def get_database_connection():
    try:
        return mysql.connector.connect(host="localhost", user="root", password="", database="test")
    except mysql.connector.Error as err:
        messagebox.showerror("Erreur", f"Erreur de connexion à la base de données: {err}")
        return None

# Fonction Ajouter
def Ajouter():
    matricule = txtNumero.get()
    nom = txtNom.get()
    prenom = txtPrenom.get()
    groupe = txtGroupe.get()
    niveau = comboNiveau.get()
    note = txtNote.get()

    if not matricule or not nom or not prenom or not groupe or not niveau or not note:
        messagebox.showwarning("Attention", "Tous les champs sont obligatoires !")
        return

    try:
        note = float(note)
    except ValueError:
        messagebox.showwarning("Attention", "La note doit être un nombre valide.")
        return

    maBase = get_database_connection()
    if maBase is None:
        return

    meConnect = maBase.cursor()
    try:
        sql = "INSERT INTO gestion (MATRICULE,NOM,PRENOM,GROUPE,NIVEAU,NOTE) VALUES (%s, %s, %s, %s, %s, %s)"
        val = (matricule, nom, prenom, groupe, niveau, note)
        meConnect.execute(sql, val)
        maBase.commit()
        messagebox.showinfo("Information", "Note ajoutée avec succès !")
        charger_table()
    except mysql.connector.Error as e:
        messagebox.showerror("Erreur", f"Une erreur SQL est survenue: {e}")
        maBase.rollback()
    finally:
        maBase.close()

# Fonction Modifier
def Modifier():
    matricule = txtNumero.get()
    nom = txtNom.get()
    prenom = txtPrenom.get()
    groupe = txtGroupe.get()
    niveau = comboNiveau.get()
    note = txtNote.get()

    if not matricule:
        messagebox.showwarning("Attention", "Le matricule est obligatoire pour modifier un étudiant !")
        return

    try:
        note = float(note)
    except ValueError:
        messagebox.showwarning("Attention", "La note doit être un nombre valide.")
        return

    maBase = get_database_connection()
    if maBase is None:
        return

    meConnect = maBase.cursor()
    try:
        sql = "UPDATE gestion SET NOM=%s, PRENOM=%s, GROUPE=%s, NIVEAU=%s, NOTE=%s WHERE MATRICULE=%s"
        val = (nom, prenom, groupe, niveau, note, matricule)
        meConnect.execute(sql, val)
        maBase.commit()
        messagebox.showinfo("Information", "Modification réussie !")
        charger_table()
    except mysql.connector.Error as e:
        messagebox.showerror("Erreur", f"Une erreur SQL est survenue: {e}")
        maBase.rollback()
    finally:
        maBase.close()

# Fonction Supprimer
def Supprimer():
    matricule = txtNumero.get()

    if not matricule:
        messagebox.showwarning("Attention", "Le matricule est obligatoire pour supprimer un étudiant !")
        return

    maBase = get_database_connection()
    if maBase is None:
        return

    meConnect = maBase.cursor()
    try:
        sql = "DELETE FROM gestion WHERE MATRICULE=%s"
        val = (matricule,)
        meConnect.execute(sql, val)
        maBase.commit()
        messagebox.showinfo("Information", "Étudiant supprimé avec succès !")
        charger_table()
    except mysql.connector.Error as e:
        messagebox.showerror("Erreur", f"Une erreur SQL est survenue: {e}")
        maBase.rollback()
    finally:
        maBase.close()

# Fonction pour sélectionner une ligne du tableau
def selectionner_etudiant(event):
    for item in table.selection():
        values = table.item(item, "values")
        txtNumero.delete(0, END)
        txtNumero.insert(0, values[0])
        txtNom.delete(0, END)
        txtNom.insert(0, values[1])
        txtPrenom.delete(0, END)
        txtPrenom.insert(0, values[2])
        txtGroupe.delete(0, END)
        txtGroupe.insert(0, values[3])
        comboNiveau.set(values[4])
        txtNote.delete(0, END)
        txtNote.insert(0, values[5])

# Fonction pour charger les données dans la table
def charger_table():
    for row in table.get_children():
        table.delete(row)
    maBase = get_database_connection()
    if maBase is None:
        return
    meConnect = maBase.cursor()
    try:
        meConnect.execute("SELECT * FROM gestion")
        rows = meConnect.fetchall()
        for row in rows:
            table.insert('', END, values=row)
    except mysql.connector.Error as e:
        messagebox.showerror("Erreur", f"Une erreur SQL est survenue: {e}")
    finally:
        maBase.close()


# La fenêtre principale
root = Tk()
root.title("ESPACE PROFESSEUR")
root.configure(background="#091821")

# Mode plein écran
root.state('zoomed')

# Dimensions de l'écran
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Fonction utilitaire pour centrer les widgets
def center_widget(widget, relx, rely, width=400, height=40):
    widget.place(relx=relx, rely=rely, anchor=CENTER, width=width, height=height)

# Bouton Déconnexion
btnretour = Button(root, text="Deconnexion", font=("Arial", 16), bg="#02691E", fg="white", command=Retour)
center_widget(btnretour, relx=0.5, rely=0.9, width=200, height=50)


# Ajout du titre
lbltitre = Label(root, borderwidth=3, relief=SUNKEN, text="GESTION ETUDIANTS", font=("Sans Serif", 25), background="#2F4F4F", fg="#FFFAFA")
lbltitre.place(x=0, y=0, width=1700, height=100)

# Champs de saisie
lblNumero = Label(root, text="MATRICULE", font=("Arial", 10), bg="#091821", fg="white")
lblNumero.place(x=70, y=150, width=150)
txtNumero = Entry(root, bd=4, font=("Arial", 14))
txtNumero.place(x=250, y=150, width=150)

lblNom = Label(root, text="NOM", font=("Arial", 10), bg="#091821", fg="white")
lblNom.place(x=70, y=200, width=150)
txtNom = Entry(root, bd=4, font=("Arial", 14))
txtNom.place(x=250, y=200, width=300)

lblPrenom = Label(root, text="PRENOM", font=("Arial", 10), bg="#091821", fg="white")
lblPrenom.place(x=70, y=250, width=150)
txtPrenom = Entry(root, bd=4, font=("Arial", 14))
txtPrenom.place(x=250, y=250, width=300)

lblGroupe = Label(root, text="GROUPE", font=("Arial", 10), bg="#091821", fg="white")
lblGroupe.place(x=70, y=300, width=150)
txtGroupe = Entry(root, bd=4, font=("Arial", 14))
txtGroupe.place(x=250, y=300, width=300)

lblNiveau = Label(root, text="NIVEAU", font=("Arial", 10), bg="#091821", fg="white")
lblNiveau.place(x=70, y=350, width=150)
comboNiveau = ttk.Combobox(root, font=("Arial", 14))
comboNiveau['values'] = ['L1', 'L2', 'L3', 'M1', 'M2']
comboNiveau.place(x=250, y=350, width=130)

lblNote = Label(root, text="NOTE", font=("Arial", 10), bg="#091821", fg="white")
lblNote.place(x=70, y=400, width=150)
txtNote = Entry(root, bd=4, font=("Arial", 14))
txtNote.place(x=250, y=400, width=300)

# Boutons
def ajouter_boutons():
    btnajouter = Button(root, text="Ajouter", font=("Arial", 16), bg="#02691E", fg="white", command=Ajouter)
    btnajouter.place(x=250, y=450, width=200)

    btnmodifier = Button(root, text="Modifier", font=("Arial", 16), bg="#02691E", fg="white", command=Modifier)
    btnmodifier.place(x=250, y=500, width=200)

    btnsupprimer = Button(root, text="Supprimer", font=("Arial", 16), bg="#02691E", fg="white", command=Supprimer)
    btnsupprimer.place(x=250, y=550, width=200)

   
ajouter_boutons()

# Tableau des étudiants
table = ttk.Treeview(root, columns=(1, 2, 3, 4, 5, 6), height=5, show="headings")
table.place(x=560, y=150, width=790, height=450)

# En-têtes du tableau
table.heading(1, text="MATRICULE")
table.heading(2, text="NOM")
table.heading(3, text="PRENOM")
table.heading(4, text="GROUPE")
table.heading(5, text="NIVEAU")
table.heading(6, text="NOTE")

# Dimensions des colonnes
table.column(1, width=100)
table.column(2, width=150)
table.column(3, width=150)
table.column(4, width=100)
table.column(5, width=100)
table.column(6, width=100)

# Lier l'événement de sélection
table.bind("<ButtonRelease-1>", selectionner_etudiant)

# Charger les données initiales
charger_table()

# Boucle principale
root.mainloop()
