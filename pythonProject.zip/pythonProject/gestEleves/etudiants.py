import mysql.connector
from subprocess import call
from tkinter import ttk, Tk
from tkinter import *
from tkinter import messagebox

# Fonction pour revenir à l'écran de connexion
def Retour():
    root.destroy()
    call(["python", "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\connexion.py"])

# Création de la fenêtre principale
root = Tk()
root.title("ESPACE ETUDIANTS")
root.configure(background="#091821")

# Mode plein écran
root.state('zoomed')

# Dimensions de l'écran
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

# Fonction utilitaire pour centrer les widgets
def center_widget(widget, relx, rely, width=400, height=40):
    widget.place(relx=relx, rely=rely, anchor=CENTER, width=width, height=height)

# Bouton Déconnexion
btnretour = Button(root, text="Deconnexion", font=("Arial", 16), bg="#02691E", fg="white", command=Retour)
center_widget(btnretour, relx=0.5, rely=0.9, width=200, height=50)

# Création de la table
table = ttk.Treeview(root, columns=(1, 2, 3, 4, 5, 6), show="headings")
table.place(relx=0.5, rely=0.5, anchor=CENTER, width=screen_width * 0.7, height=screen_height * 0.6)

# En-têtes de la table
table.heading(1, text="MAT")
table.heading(2, text="NOM")
table.heading(3, text="PRENOM")
table.heading(4, text="GROUPE")
table.heading(5, text="NIVEAU")
table.heading(6, text="NOTE")

# Définition des dimensions des colonnes
table.column(1, width=100)
table.column(2, width=200)
table.column(3, width=200)
table.column(4, width=150)
table.column(5, width=100)
table.column(6, width=150)

# Connexion à la base de données et affichage des données
maBase = mysql.connector.connect(host="localhost", user="root", password="", database="test")
meConnect = maBase.cursor()

try:
    meConnect.execute("SELECT * FROM gestion")
    rows = meConnect.fetchall()
    if rows:
        for row in rows:
            table.insert('', END, value=row)
    else:
        messagebox.showinfo("Information", "Aucun résultat trouvé")
except Exception as e:
    print(e)
finally:
    maBase.close()

# Lancement de la boucle principale de l'interface
root.mainloop()
