import mysql.connector
from subprocess import call
from tkinter import ttk, Tk
from tkinter import *
from tkinter import messagebox


# Fonction pour s'inscrire
def Inscrire():
    nom = txtnom.get().strip()
    prenom = txtprenom.get().strip()
    user = txtnomUtilisateur.get().strip()
    password = txtmdp.get().strip()
    statut = combostatut.get().strip()

    # Vérification que tous les champs sont remplis
    if not (nom and prenom and user and password and statut):
        messagebox.showerror("Erreur", "Veuillez remplir tous les champs avant de valider.")
        return

    maBase = mysql.connector.connect(host="localhost", user="root", password="", database="test")
    meConnect = maBase.cursor()
    try:
        sql = "INSERT INTO inscription (prenom, nom, user, password, statut) VALUES (%s, %s, %s, %s, %s)"
        val = (prenom, nom, user, password, statut)
        meConnect.execute(sql, val)
        maBase.commit()

        messagebox.showinfo("Information", "Inscription réussie")
        root.destroy()
        call(["python", "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\inscription.py"])
    except Exception as e:
        print(e)
        maBase.rollback()
    finally:
        maBase.close()


# Fonction pour aller à la page de connexion
def Connect():
    try:
        root.destroy()
        call(["python", "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\connexion.py"])
    except Exception as e:
        print(e)


# Création de la fenêtre principale
root = Tk()
root.title("Fenêtre d'inscription")
root.configure(background="#091821")

# Mode plein écran
root.state('zoomed')

# Dimensions de la fenêtre
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()


# Fonction utilitaire pour centrer les widgets
def center_widget(widget, relx, rely, width=400, height=40):
    widget.place(relx=relx, rely=rely, anchor=CENTER, width=width, height=height)


# Titre principal
lbltitre = Label(root, text="Formulaire d'inscription", font=("Sans Serif", 30), bg="#091821", fg="white")
center_widget(lbltitre, relx=0.5, rely=0.1, width=600)

# Champs de saisie pour le prénom
lblprenom = Label(root, text="Prénom:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblprenom, relx=0.4, rely=0.25)
txtprenom = Entry(root, bd=4, font=("Arial", 16))
center_widget(txtprenom, relx=0.6, rely=0.25)

# Champs de saisie pour le nom
lblnom = Label(root, text="Nom:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblnom, relx=0.4, rely=0.35)
txtnom = Entry(root, bd=4, font=("Arial", 16))
center_widget(txtnom, relx=0.6, rely=0.35)

# Champs de saisie pour le nom d'utilisateur
lblutilisateur = Label(root, text="Nom utilisateur:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblutilisateur, relx=0.4, rely=0.45)
txtnomUtilisateur = Entry(root, bd=4, font=("Arial", 16))
center_widget(txtnomUtilisateur, relx=0.6, rely=0.45)

# Champs de saisie pour le mot de passe
lblmdp = Label(root, text="Mot de passe:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblmdp, relx=0.4, rely=0.55)
txtmdp = Entry(root, show="*", bd=4, font=("Arial", 16))
center_widget(txtmdp, relx=0.6, rely=0.55)

# Liste déroulante pour le statut
lblstatut = Label(root, text="Statut:", font=("Arial", 18), bg="#091821", fg="white")
center_widget(lblstatut, relx=0.4, rely=0.65)
combostatut = ttk.Combobox(root, font=("Arial", 16))
combostatut['values'] = ['Étudiant', 'Professeur']
center_widget(combostatut, relx=0.6, rely=0.65)

# Bouton pour valider l'inscription
btnenregistrer = Button(root, text="Valider", font=("Arial", 16), bg="#FF4500", fg="white", command=Inscrire)
center_widget(btnenregistrer, relx=0.5, rely=0.75)

# Bouton pour quitter
btnquitter = Button(root, text="Quitter", font=("Arial", 16), bg="#FF4500", fg="white", command=root.quit)
center_widget(btnquitter, relx=0.5, rely=0.85, width=200)

# Lien vers la page de connexion
btnconnexion = Button(root, text="Connecte-toi !", cursor="hand2", font=("Arial", 16), bg="#091821", fg="#FF4500",
                      bd=0, command=Connect)
center_widget(btnconnexion, relx=0.5, rely=0.92)

# Démarrage de la fenêtre principale
root.mainloop()
