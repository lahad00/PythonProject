import tkinter as tk
from subprocess import call

# Fonction pour accéder à la page de connexion
def page_connexion():
    root.destroy()
    call(["python",  "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\connexion.py"])

# Fonction pour accéder à la page d'inscription
def page_inscription():
    root.destroy()
    call(["python", "C:\\Users\\Lahad\\OneDrive\\Documents\\KONAMI\\pythonProject\\gestEleves\\inscription.py"])

# Création de la fenêtre principale
root = tk.Tk()
root.title("Page d'accueil")
root.geometry("1000x500+0+0")
root.configure(background="#091821")  # Couleur de fond sombre



# Titre principal
title_label = tk.Label(root, text="Bienvenue sur la plateforme de gestion des étudiants", 
                       font=("Sans Serif", 25), bg="#2F4F4F", fg="#FFFAFA")  # Couleurs principales
title_label.pack(pady=20, ipadx=10, ipady=10, fill="x")

# Texte introductif
intro_label = tk.Label(root, text="Veuillez choisir une option pour continuer", 
                       font=("Arial", 16), bg="#091821", fg="white")
intro_label.pack(pady=10)

# Bouton pour accéder à la page de connexion
btn_connexion = tk.Button(root, text="Connexion",  font=("Arial", 16), bg="#FF4500", fg="white",
command=page_connexion)
btn_connexion.pack(pady=20, ipadx=20, ipady=10)

# Bouton pour accéder à la page d'inscription
btn_inscription = tk.Button(root, text="Inscription", font=("Arial", 16), bg="#FF4500", fg="white",
                            command=page_inscription)
btn_inscription.pack(pady=20, ipadx=20, ipady=10)

# Bouton pour quitter l'application
btn_quit = tk.Button(root, text="Quitter", font=("Arial", 14), bg="#8B0000", fg="white", 
                     command=root.quit)
btn_quit.pack(pady=30, ipadx=20, ipady=5)

# Boucle principale de l'application
root.mainloop()
