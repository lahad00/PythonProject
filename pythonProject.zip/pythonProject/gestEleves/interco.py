#Bibliothèques
from subprocess import call
from tkinter import ttk, Tk
from tkinter import *
from tkinter import messagebox
import mysql.connector as mysql



#Fonction Connexion
def Connecter():
    surnom = txtnomUtilisateur.get()
    mdp = txtmdp.get()
    staut = combostatut.get()
    if (surnom == "" and mdp == ""):
        messagebox.showerror("","Veuillez renseigner les données")
        txtmdp.delete("0", "end")
        txtnomUtilisateur.delete("0", "end")
    elif (surnom == "admin" and mdp == "admin" and staut== "Professeur"):
        messagebox.showinfo("", "Bienvenue")
        txtmdp.delete("0", "end")
        txtnomUtilisateur.delete("0", "end")
        root.destroy()
        call(["python","Menu_principal.py"])
    elif (surnom == "student" and mdp == "student" and staut== "Etudiant"):
        messagebox.showinfo("", "Bienvenue")
        txtmdp.delete("0", "end")
        txtnomUtilisateur.delete("0", "end")
        root.destroy()
        call(["python","etudiants.py"])
    else:
        messagebox.showwarning("","Erreur de connexion")
        txtmdp.delete("0", "end")
        txtnomUtilisateur.delete("0", "end")






#La fenetre
root = Tk()

root.title("FENETRE DE CONNEXION")
root.geometry("400x300+450+200")
root.resizable(False, False)
root.configure(background="#091821")



#Ajout Titre
lbltitre = Label(root,borderwidth= 3,relief=SUNKEN
                 , text="Formulaire de connexion", font=("Sans Serif",25), background="#091821" ,fg="white")
lbltitre.place(x= 0, y=0, width =400)

lblutilisateur = Label(root, text= "Nom utilsateur:", font=("Arial",14),bg="#091821", fg="white")
lblutilisateur.place(x= 5, y=100, width =150)
txtnomUtilisateur = Entry(root,bd=4, font=("Arial",13))
txtnomUtilisateur.place(x=150, y=100, width=200, height=30)

lblmdp = Label(root, text= "Mot de passe:", font=("Arial",14),bg="#091821", fg="white")
lblmdp.place(x= 5, y=150, width =150)
txtmdp = Entry(root,show="*", bd=4, font=("Arial",13))
txtmdp.place(x=150, y=150, width=200, height=30)


#Statut
lblstatut = Label(root, text="Statut", font=("Arial", 14), bg = "#091821", fg = "white")
lblstatut.place(x=5, y=200, width=150)
combostatut = ttk.Combobox(root, font=("Arial",14))
combostatut['values'] = ['Etudiant','Professeur']
combostatut.place(x=150, y=200, width=200, height=30)






#Bouton Connecter
btnenregistrer = Button(root, text="Connexion",font=("Arial",10), bg="#FF4500",fg="white", command=Connecter)
btnenregistrer.place(x=150, y=250, width=200, height=30)





root.mainloop()